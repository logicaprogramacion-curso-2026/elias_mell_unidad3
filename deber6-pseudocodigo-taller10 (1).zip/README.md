# Deber 6 - Pseudocódigo del Taller 10

* **Asignatura:** Lógica de Programación 01-SIG-A
* **Estudiante:** Mell Elias ladinez
* **Universidad:** Universidad Internacional del Ecuador (UIDE)
* **Fecha de entrega:** 11 de agosto de 2026

## Descripción de la Actividad
Desarrollo del pseudocódigo correspondiente al Taller 10.

## Estructura del Proyecto
* `taller10_pseudocodigo.txt`: Archivo que contiene el pseudocódigo solicitado.
* `README.md`: Documentación de la tarea.
