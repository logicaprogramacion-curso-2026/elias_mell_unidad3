class docente:
    def _intit_(self,
                nombre = None,
                direccion = None,
                telefono = None,
                email = None):
        print ("contructor con argumentos")